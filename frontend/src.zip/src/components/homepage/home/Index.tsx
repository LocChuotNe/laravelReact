import { useEffect, useState } from "react";
import SideNav from "../common/SideNav";
import User from "../../user/User";

function getTabFromURL() {
  const q = new URLSearchParams(window.location.search);
  return q.get("tab") || "dashboard";
}

export default function Index() {
  const [activeMenu, setActiveMenu] = useState<string>(getTabFromURL());

  // Cập nhật activeMenu khi người dùng back/forward
  useEffect(() => {
    const onPop = () => setActiveMenu(getTabFromURL());
    window.addEventListener("popstate", onPop);
    return () => window.removeEventListener("popstate", onPop);
  }, []);

  return (
    <div className="flex mt-[4.7rem] md:mt-0">
      <nav className="side-nav">
        <SideNav activeMenu={activeMenu} setActiveMenu={setActiveMenu} />
      </nav>

      <div className="content">
        <div className="top-bar flex items-center">
          <h1>đây là hiển thị header topbar</h1>
          {/* (Tuỳ chọn) Hiển thị đường dẫn API khi đang ở trang Users */}
          {activeMenu === "users" && (
            <span className="ml-auto text-xs text-slate-500">
              GET http://127.0.0.1:8000/api/users
            </span>
          )}
        </div>

        {activeMenu === "users" ? (
          <User />
        ) : (
          <div className="p-10 text-center text-slate-600">
            <h2 className="text-2xl font-semibold mb-2">Chào mừng bạn đến trang quản trị 🎉</h2>
            <p>Vui lòng chọn menu bên trái để bắt đầu thao tác.</p>
          </div>
        )}
      </div>
    </div>
  );
}
