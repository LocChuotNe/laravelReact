import axios from "axios";

const API = axios.create({
  baseURL: import.meta.env.VITE_API_URL || "http://127.0.0.1:8000/api",
  headers: {
    "Content-Type": "application/json",
    Accept: "application/json",
  },
});

API.interceptors.request.use((config) => {
  const token = localStorage.getItem("auth_token");
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

API.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      // Token hết hạn hoặc không hợp lệ
      localStorage.removeItem("auth_token");
      window.location.href = "/login";
    }API.interceptors.request.use((config) => {
    return Promise.reject(error);
  }
);

// Auth APIs
export const register = (data: any) => API.post("/register", data);
export const login = (data: any) => API.post("/login", data);
export const logout = () => {
  localStorage.removeItem("auth_token");
  return API.post("/logout");
};

// User APIs
export const getUsers = () => API.get("/users");
export const getUserById = (id: number) => API.get(`/users/${id}`);
export const createUser = (data: any) => API.post("/users", data);
export const updateUser = (id: number, data: any) => API.put(`/users/${id}`, data);
export const deleteUser = (id: number) => API.delete(`/users/${id}`);

// Dashboard APIs
export const getDashboardData = () => API.get("/dashboard");

export default API;